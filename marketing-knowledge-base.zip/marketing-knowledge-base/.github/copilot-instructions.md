# Copilot Instructions

Use `SKILL.md` as the master marketing protocol. Before drafting marketing assets, diagnose audience, desire, awareness, sophistication, positioning, mechanism, proof, and friction as relevant. Do not invent claims or evidence. Prefer repository frameworks over generic marketing clichés.
